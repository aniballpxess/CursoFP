package Bucles;

/*
 * programa que muestra los números del 1 al 10
 */
public class Bucle_5_DiHolaAlBucleFor {
    public static void main(String[] args) {
        int i;
        for (i = 1; i <= 10; i++) {    //inicio del for
            System.out.print(i + " ");
        }  //fin del for
        System.out.println("\nFin programa");
    }
}