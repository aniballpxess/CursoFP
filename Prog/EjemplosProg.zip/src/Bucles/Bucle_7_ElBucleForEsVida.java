package Bucles;

// Programa que muestra los números del 10 al 1
public class Bucle_7_ElBucleForEsVida {
    public static void main(String[] args) {
        for (int i = 10; i > 0; i--) {    //inicio del for
            System.out.print(i + " ");
        }  //fin del for
        System.out.println("\nFin programa");
    }
}
