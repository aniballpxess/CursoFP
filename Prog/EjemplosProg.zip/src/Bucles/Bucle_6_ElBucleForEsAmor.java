package Bucles;

// Programa que muestra los números del 1 al 10
public class Bucle_6_ElBucleForEsAmor {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {    //inicio del for
            System.out.print(i + " ");
        }  //fin del for
        System.out.println("\nFin programa");
    }
}
