package Clases.Persona;

public class Registro {
    private Persona datosPersonales;
    private Integer idCliente;
    private Boolean activo;

    public Registro(Integer edadPersona, String nombrePersona) {
        this.setDatosPersonales(edadPersona, nombrePersona);
        this.setIdCliente(null);
        this.setActivo(false);
    }
    public Registro(Integer edadPersona, String nombrePersona, Integer idCliente) {
        this.setDatosPersonales(edadPersona, nombrePersona);
        this.setIdCliente(idCliente);
        this.setActivo(true);
    }

    private void setDatosPersonales(Integer edadPersona, String nombrePersona) {
        this.datosPersonales = new Persona(edadPersona, nombrePersona);
    }

    private void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    private void setActivo(Boolean activo) {
        this.activo = activo;
    }

    public Persona getDatosPersonales() {
        return datosPersonales;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public Boolean isActivo() {
        return activo;
    }

    public void activarCuenta(Integer idCliente) {
        if (this.isActivo()) {
            System.out.println("La cuenta ya está activa.");
        } else {
            this.setActivo(true);
            this.setIdCliente(idCliente);
            System.out.println("La cuenta ha sido activada.");
        }
    }

    public void desactivarCuenta() {
        if (!this.isActivo()) {
            System.out.println("La cuenta ya está inactiva.");
        } else {
            this.setActivo(false);
            this.setIdCliente(null);
            System.out.println("La cuenta ha sido desactivada.");
        }
    }

    @Override
    public String toString() {
        if (this.isActivo()) {
            return "INFO REGISTRO\n" +
                    datosPersonales.toString() +
                    "Cuenta: activa\n" +
                    "Nº Cliente: " + idCliente + "\n";
        } else {
            return "INFO REGISTRO\n" +
                    datosPersonales.toString() +
                    "Cuenta: inactiva\n";
        }
    }
}
