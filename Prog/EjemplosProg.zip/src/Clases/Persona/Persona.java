package Clases.Persona;

public class Persona {
    private Integer edadPersona;
    private String nombrePersona;

    public Persona(Integer edad, String nombrePersona){
        setEdadPersona(edad);
        setNombrePersona(nombrePersona);
    }

    public void setEdadPersona(Integer edadPersona) {
        this.edadPersona = edadPersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public Integer getEdadPersona() {
        return edadPersona;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    @Override
    public String toString() {
        return "Datos Personales\n" +
               "    Nombre: " + nombrePersona + "\n" +
               "    Edad: " + edadPersona + "\n";
    }
}
