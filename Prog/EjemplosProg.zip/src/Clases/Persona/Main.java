package Clases.Persona;

public class Main {
    public static void main(String[] args) {
        Registro cliente1 = new Registro(26,"Marcos");
        System.out.println(cliente1.toString());
        cliente1.activarCuenta(1);
        cliente1.activarCuenta(4);
        System.out.println();
        System.out.println(cliente1.toString());
        cliente1.desactivarCuenta();
        cliente1.desactivarCuenta();
        System.out.println();
        System.out.println(cliente1.toString());
    }
}
