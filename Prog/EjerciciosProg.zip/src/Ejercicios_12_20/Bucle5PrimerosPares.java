package Ejercicios_12_20;

public class Bucle5PrimerosPares {
    public static void main(String[] args) {
        // Bucle que imprime los 5 primeros pares en una sola línea
        for (int i = 0; i < 10; i += 2) {
            System.out.print(i + " ");
        }
    }
}
